let arr=[3,8,2,5,4,10,7,6]

let b = arr[0];
let t;

for(let i = 0; i < arr.length; i++){
    if(b>=arr[i]){
        b = arr[i]
        t = i;
    }
}

console.log(t);