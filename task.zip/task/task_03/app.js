let arr=[3,8,2,5,4,10,7,6]
let b = arr[0];

for(let i = 0; i < arr.length; i++){
    if(b<=arr[i]){
        b = arr[i]
    }
}
console.log(b);
