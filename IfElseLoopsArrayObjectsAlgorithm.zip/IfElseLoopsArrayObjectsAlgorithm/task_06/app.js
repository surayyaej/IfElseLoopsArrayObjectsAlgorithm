let arr=[3,8,2,5,4,10,7,6]

let a = arr[0];
let b = arr[0];

for(let i = 0; i < arr.length; i++){
    if(a<=arr[i]){
        a = arr[i];
    }
    else if(b >= arr[i]){
        b = arr[i];
    }
}

for(let i = 0; i < arr.length; i++){
    if(arr[i]===a){
        arr[i]=b;
    }
    else if(arr[i]===b){
        arr[i]=a;
    }
}

console.log(arr);