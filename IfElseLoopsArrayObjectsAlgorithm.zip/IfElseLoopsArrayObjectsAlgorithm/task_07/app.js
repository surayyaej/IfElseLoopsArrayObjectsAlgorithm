let arr = [3, 8, 2, 5, 4, 10, 7, 6];

let smallestEven = arr[0];
let largestOdd = arr[0];

for(let i = 0; i < arr.length; i++){
    if(arr[i] % 2 == 0 && arr[i] <= smallestEven) {
        smallestEven = arr[i];
    }
    else if(arr[i] % 2 != 0 && arr[i] >= largestOdd) {
        largestOdd = arr[i];
    }
}

for(let i = 0; i < arr.length; i++){
    if(arr[i] === smallestEven){
        arr[i] = largestOdd;
    }
    else if(arr[i] === largestOdd){
        arr[i] = smallestEven;
    }
}

console.log(arr);
